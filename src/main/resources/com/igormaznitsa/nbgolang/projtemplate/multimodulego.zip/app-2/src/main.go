package main

import "common"

func main() {
	common.PrintHello("universe")
}
