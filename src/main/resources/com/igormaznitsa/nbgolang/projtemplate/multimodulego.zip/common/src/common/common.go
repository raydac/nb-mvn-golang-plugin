package common

import "fmt"

func PrintHello(name string) {
	fmt.Println("Hello," + name)
}
