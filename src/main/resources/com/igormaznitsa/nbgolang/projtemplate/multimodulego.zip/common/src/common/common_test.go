package common

import "testing"

func TestPrintHello(t *testing.T) {
	PrintHello("Igor")
}
